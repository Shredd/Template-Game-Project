import os
import pygame

x = 450
y = 250
width = 40
height = 60
player_color = (0, 0, 70)

vel = 15
left = False
right = False
up = False
down = False
Idle = True


