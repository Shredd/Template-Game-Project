import os
import Player
import pygame

def setStat(CharNum):
	if CharNum == 1:
		Player.vel = 4
	if CharNum == 2:
		Player.vel = 8
	if CharNum == 3:
		Player.vel = 12


  
	


