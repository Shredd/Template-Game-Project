import os
import pygame

def Draw_Image(win, Image, x, y, width, height):
	win.blit(Image, (x,y,width,height))
	
