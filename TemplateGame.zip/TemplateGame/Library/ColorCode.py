import os
import pygame

Black = (0,0,0)
White = (255,255,255)
Red = (255,0,0)
Blue = (0,0,255)
Green = (0,255,0)
	


